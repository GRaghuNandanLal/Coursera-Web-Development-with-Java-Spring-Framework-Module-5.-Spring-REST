package com.lylechristine.musicstore.converter;

import java.util.ArrayList;

import com.lylechristine.musicstore.entity.AlbumEntity;
import com.lylechristine.musicstore.entity.ArtistEntity;
import com.lylechristine.musicstore.model.AlbumModel;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Service;

@Service
public class AlbumEntityToAlbumModelConvertor implements Converter<AlbumEntity, AlbumModel>{

    @Override
    public AlbumModel convert(AlbumEntity source) {

        if (source == null) {
            return null;
        }

        AlbumModel res = new AlbumModel(source.getId(), source.getTitle(), source.getDescription(), new ArrayList<String>());

        for (ArtistEntity artist: source.getArtists()) {
            res.getArtists().add(artist.getName());
        }

        return res;
    }
}
