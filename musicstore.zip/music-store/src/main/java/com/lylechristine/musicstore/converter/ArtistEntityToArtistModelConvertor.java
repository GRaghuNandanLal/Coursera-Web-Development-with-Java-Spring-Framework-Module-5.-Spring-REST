package com.lylechristine.musicstore.converter;

import com.lylechristine.musicstore.entity.ArtistEntity;
import com.lylechristine.musicstore.model.ArtistModel;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Service;

@Service
public class ArtistEntityToArtistModelConvertor implements Converter<ArtistEntity, ArtistModel> {

    @Override
    public ArtistModel convert(ArtistEntity source) {

        if (source == null)
            return null;

        return new ArtistModel(source.getId(), source.getName());
    }

}
