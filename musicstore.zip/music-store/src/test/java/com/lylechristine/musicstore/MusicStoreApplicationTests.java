package com.lylechristine.musicstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MusicStoreApplicationTests {

    @Test
    void contextLoads() {
    }

}
